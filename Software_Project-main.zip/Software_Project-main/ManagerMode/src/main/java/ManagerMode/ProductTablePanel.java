/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManagerMode;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author PARKSOHYUN
 */
public class ProductTablePanel extends JPanel {
    private JTable productTable;
    private DefaultTableModel model;
    private String[] columns;
    
    ProductTablePanel hotelPanel;
    ProductTablePanel airlinePanel;
    ProductTablePanel rentalcarPanel;
    
    public ProductTablePanel(String[] columns) {
        this.columns = columns;
        initPanels();
    }
        
    
    public void initPanels() {
        setLayout(new BorderLayout());
        createProductTable();
                
        //스크롤 가능
        JScrollPane scrollPane = new JScrollPane(productTable);
        scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.add(scrollPane, BorderLayout.CENTER);
    }
    
    private void createProductTable() {
        model = new DefaultTableModel(columns, 0);
     
        // 테이블 만들기   
        productTable = new JTable(model);
        productTable.setPreferredScrollableViewportSize(new Dimension(400, 500));
        productTable.setFillsViewportHeight(true);     
    }
    
    public void settingProducts(JRadioButton btn1,JRadioButton btn2,JRadioButton btn3) {
        //호텔, 항공, 관리자 세 개의 테이블 구성
        //아직 구현중!!!!!!!!!!!!!!!!!
        
        String[] hotelColumns = {"비즈니스 넘버", "호텔 명", "지역", "상세 주소", 
            "투숙객 수", "조식 여부", "룸 타입", "숙박 비용", "등록 여부"};
        hotelPanel = new ProductTablePanel(hotelColumns);
        hotelPanel.loadDataFromTextFile("hotel_buisness_textfile.txt");
        //파일 경로 지정 필요(EX.절대 경로)
        
        
        String[] airlineColumns = {"비즈니스 넘버", "항공사", "출발 지역", "도착 지역",
            "좌석 타입", "왕복/편도", "항공권 가격", "등록 여부"};
        airlinePanel = new ProductTablePanel(airlineColumns);
        airlinePanel.loadDataFromTextFile("airline_buisness_textfile.txt");
        
        String[] rentalcarColumns = {"비즈니스 넘버", "자동차 회사", "대여 시간", "비용",
            "차종", "연료", "하이패스", "등록 여부"};            
        rentalcarPanel = new ProductTablePanel (rentalcarColumns);
        rentalcarPanel.loadDataFromTextFile("rentalcar");
                                
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showPanel(hotelPanel);
            }
        });
        //이거왜안돼
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showPanel(airlinePanel);
            }
        });
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showPanel(rentalcarPanel);
            }
        });        
        
    }
    
    public void showPanel(ProductTablePanel panel) {
        //모든 패널 숨기기
        hotelPanel.setVisible(false);
        airlinePanel.setVisible(false);
        rentalcarPanel.setVisible(false);
        
        //선택된 패널만 보임
        panel.setVisible(true);
        
        //패널을 현재 보이는 컨테이너에 추가
        add(panel,BorderLayout.CENTER);
        validate();
        repaint();
    }
        
       
        
    
    public void addRow(Object[] row) {
        model.addRow(row);
    }
    
    public void loadDataFromTextFile(String filename) {
        //구현중...
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while((line = br.readLine()) != null) {
                String[] rowData = line.split("\t");
                addRow(rowData);
            }
        } catch (IOException e){
            e.printStackTrace();
        }     
    } 
}
      

