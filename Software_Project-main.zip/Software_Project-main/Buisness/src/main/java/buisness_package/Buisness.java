/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package buisness_package;

/**
 *
 * @author mskim
 */
public class Buisness {

    public static void main(String[] args) {
        Business_Choice b = new Business_Choice();
        
    }
}
